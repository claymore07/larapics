<div>
    Button
</div>
<?php /**PATH C:\wamp64\www\larapics\resources\views/components/ui/button.blade.php ENDPATH**/ ?>