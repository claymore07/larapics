<div class="row image-grid" data-masonry='{"percentPosition": true }'>
    <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-6 col-lg-4 mb-4">
        <div class="card">
            <a href="<?php echo e($image->permaLink()); ?>"
            ><img
                src="<?php echo e($image->fileUrl()); ?>"
                alt="<?php echo e($image->title); ?>"
                height="100%"
                class="card-img-top"
            /></a>

        </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php echo e($images->links()); ?>

<?php /**PATH C:\wamp64\www\larapics\resources\views/shared/_grid-images.blade.php ENDPATH**/ ?>