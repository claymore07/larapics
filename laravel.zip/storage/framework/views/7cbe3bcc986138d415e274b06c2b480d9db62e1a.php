
<?php if($relatedImages->count()): ?>
    <h3 class="mt-5">Related Photos</h3>
    <div class="row mt-3">
        <?php $__currentLoopData = $relatedImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col">
                    <a href="<?php echo e($image->permaLink()); ?>"><img src="<?php echo e($image->fileUrl()); ?>" class="img-fluid" /></a>
                </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
<?php endif; ?>

<?php /**PATH C:\wamp64\www\larapics\resources\views/image/partials/_related_photos.blade.php ENDPATH**/ ?>