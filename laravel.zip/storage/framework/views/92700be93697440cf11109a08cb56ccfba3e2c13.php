

<img src="<?php echo e($src); ?>" <?php echo e($attributes); ?>>
<?php /**PATH C:\wamp64\www\larapics\resources\views/components/icon.blade.php ENDPATH**/ ?>