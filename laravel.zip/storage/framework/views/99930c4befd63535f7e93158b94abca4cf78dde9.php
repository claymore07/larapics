<div  <?php echo e($attributes->merge(['class' => $getClasses,'role'=> $attributes->prepends('action')])); ?> >
    <?php if(isset($title)): ?>
        <h1 class="alert-heading"><?php echo e($title); ?></h1>
    <?php endif; ?>
    <?php if(isset($message)): ?>
        <p class="mb-0"><?php echo e($message); ?></p>
    <?php endif; ?>

    <?php echo e($slot); ?>


    <?php if($dismissible): ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    <?php endif; ?>
</div>









<?php /**PATH C:\wamp64\www\larapics\resources\views/components/alert.blade.php ENDPATH**/ ?>