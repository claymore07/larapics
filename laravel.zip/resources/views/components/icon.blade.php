{{-- <div>
    Icon {{ $src }}
</div> --}}

<img src="{{ $src }}" {{ $attributes }}>
